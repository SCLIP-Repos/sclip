﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCLIP.Act.Item
{
    internal class Edit
    {
        public void Create()
        {

        }

        public void Delete()
        {

        }

        public class Stream
        {
            public Stream(string item)
            {

            }

            public void Write()
            {

            }

            public void Write(bool overwrite)
            {

            }

            public string Read()
            {
                return "";
            }
        }
    }
}
