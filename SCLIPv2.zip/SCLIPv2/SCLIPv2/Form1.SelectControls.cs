﻿namespace SCLIP
{
    public partial class Form1
    {
        internal enum SelectControls
        {
            Init,
            View,
            Edit,
            QRView
        };
    }
}
