﻿using System;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crypto
{
    public class AES
    {
        private const int _KEYSIZE = 256;


        private AesCryptoServiceProvider aesCryptoServiceProvider;

        public AES() => aesCryptoServiceProvider = new AesCryptoServiceProvider();
        
        public void SET(string key,string iv)
        {
            aesCryptoServiceProvider.KeySize = 256;

            aesCryptoServiceProvider.Mode = CipherMode.CBC;

            aesCryptoServiceProvider.Key = Encoding.UTF8.GetBytes(sixSize(key));

            aesCryptoServiceProvider.IV = Encoding.UTF8.GetBytes(sixSize(iv));

        }

        public string Encryption(string @string)
        {
            ICryptoTransform cryptoTransform = aesCryptoServiceProvider.CreateEncryptor();

            byte[] b = Encoding.UTF8.GetBytes(@string);

            try
            {
                byte[] compute = cryptoTransform.TransformFinalBlock(b, 0, b.Length);

                return Convert.ToBase64String(compute);
            }
            catch
            {
                return null;
            }

            
        }

        public string Decryption(string @string)
        {
            ICryptoTransform cryptoTransform = aesCryptoServiceProvider.CreateDecryptor();

            byte[] b = Convert.FromBase64String(@string);

            try
            {
                byte[] compute = cryptoTransform.TransformFinalBlock(b, 0,b.Length);
                
                return Encoding.UTF8.GetString(compute);
            }
            catch
            {
                return null;
            }
            
        }


        private string sixSize(string str)
        {
            if(str.Length == 16)
                return str;

            if (str.Length < 16)
            {
                for(int i = 0; i < 16 - str.Length; i++)
                    str += "*";

                return str;
            }
            else
            {
                str = str.Remove(0,16);

                return str;
            }
            
        }
             
    }
}
