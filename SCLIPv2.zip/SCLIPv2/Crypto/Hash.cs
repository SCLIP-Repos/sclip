﻿using System;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crypto
{
    public class Hash
    {
        public static string SHA256(string str,string salt)
        {
            string tmp = compute(str + salt);

            for(int i = 0; i < 3000; i++)
            
                tmp = compute(str + tmp + SHA256( salt,tmp));

            return tmp;
        }

        public static string compute(string str)
        {

            using (SHA384CryptoServiceProvider sha = new SHA384CryptoServiceProvider())
            {
                var val = sha.ComputeHash(Encoding.UTF8.GetBytes(str));

                StringBuilder stringBuilder = new StringBuilder();

                for(int i = 0; i < str.Length; i++)
                {
                    stringBuilder.AppendFormat("{0:x2}", val[i]);
                }

                return stringBuilder.ToString();
            }
        }
    }
}


/*
   using (SHA256CryptoServiceProvider sha = new SHA256CryptoServiceProvider())
            {

                var tmp = sha.ComputeHash(Encoding.UTF8.GetBytes(str));

                StringBuilder sb = new StringBuilder();

                for (int i = 0; i < tmp.Length; i++)
                {
                    sb.AppendFormat("{0:x2}", tmp[i]);
                }

                return sb.ToString();
            }
     */
