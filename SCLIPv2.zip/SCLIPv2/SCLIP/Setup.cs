﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SCLIP
{
    public partial class Setup : Form
    {
        public Setup()
        {
            InitializeComponent();
            Backupcode_textBox.Text = Guid.NewGuid().ToString("N").Substring(16);
        }


        private void CreateBc_button_Click(object sender, EventArgs e)
        {
            Backupcode_textBox.Text = Guid.NewGuid().ToString("N").Substring(16);
        }

        private void Finish_button_Click(object sender, EventArgs e)
        {
            if(NewPsw_textBox.Text != ReNewPsw_textBox.Text)
            {
                MessageBox.Show("確認入力と一致しません。");

                return;
            }

            if (NewPsw_textBox.Text.Length < 5)
            {
                MessageBox.Show("パスワードは5桁以上で設定する必要があります。");

                return;
            }

            
        }
        
    }
}
