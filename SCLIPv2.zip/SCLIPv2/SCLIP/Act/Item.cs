﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft;
using Newtonsoft.Json;
using Crypto;

namespace SCLIP.Act
{
    internal partial class Item
    {
        public void Create(string sname)
        {
            try
            {
                using(var fc = File.Create(Paths.Dirs[1] + sname)) { }
            }
            catch { }
        }

        public void Write(string sname, string str)
        {
            var proper = new ItemBox
            {
                ServiceName = sname,

                URL = str.Split(',')[1],

                ID = str.Split(',')[2],

                Mail = str.Split(',')[3],

                Psw = str.Split(',')[4],

                Memo = str.Split(',')[5]
            };


            //json形式に
            string tmp = JsonConvert.SerializeObject(proper, Formatting.Indented);


            //暗号化

            string iv = Guid.NewGuid().ToString("N").Substring(16);

            AES aes = new AES();

            aes.SET(Config.Keys.Itemlock, iv);

            tmp = aes.Encryption(tmp) + ',' + iv;


            //書き込み処理
            using (StreamWriter streamWriter = new StreamWriter(Paths.Dirs[1] + sname, false, Encoding.UTF8))
            {
                streamWriter.Write(tmp);
            }
        }

        public string Read(string sname)
        {
            string tmp;


            //存在のチェック
            //なければ無視ー＞リターン
            if (!File.Exists(Paths.Dirs[1] + sname))
                return null;
            
            
            //読み込み
            using (StreamReader streamReader = new StreamReader(Paths.Dirs[1] + sname, Encoding.UTF8))
                tmp = streamReader.ReadToEnd();



            //複合化処理
            AES aes = new AES();

            aes.SET(Config.Keys.Itemlock, tmp.Split(',')[1]);

            tmp = aes.Decryption(tmp.Split(',')[0]);


            // デジアライズ
            var str = JsonConvert.DeserializeObject<ItemBox>(tmp);


            //文字列にまとめる -> a,b,c,d,eのようにカンマ区切りの形式
            string plain = str.ServiceName + ',' + str.URL + ',' + str.ID + ',' + str.Mail + ',' + str.Psw + ',' + str.Memo;


            return plain;
        }

        public bool isItems(string sname)
        {
            if (File.Exists( Paths.Dirs[1] + sname))
                return true;

            return false;
        }
        }
}
