﻿namespace SCLIP.Act
{
    internal partial class Item
    {
        internal struct ItemBox
        {
            public  string ServiceName { get; set; }

            public string URL { get; set; }

            public string ID { get; set; }

            public string Mail { get; set; }

            public string Psw { get; set; }

            public string Memo { get; set; }

        }
    }
}
