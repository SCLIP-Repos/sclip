﻿namespace SCLIP
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Item_listBox = new System.Windows.Forms.ListBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ServiceName_textBox = new System.Windows.Forms.TextBox();
            this.URL_textBox = new System.Windows.Forms.TextBox();
            this.ID_textBox = new System.Windows.Forms.TextBox();
            this.Mail_textBox = new System.Windows.Forms.TextBox();
            this.Psw_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Memo_richTextBox = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.No_button = new System.Windows.Forms.Button();
            this.OK_button = new System.Windows.Forms.Button();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.New_button = new System.Windows.Forms.ToolStripMenuItem();
            this.Edit_button = new System.Windows.Forms.ToolStripMenuItem();
            this.Delete_button = new System.Windows.Forms.ToolStripMenuItem();
            this.Sets_button = new System.Windows.Forms.ToolStripButton();
            this.Help_button = new System.Windows.Forms.ToolStripButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Item_listBox
            // 
            this.Item_listBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Item_listBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Item_listBox.FormattingEnabled = true;
            this.Item_listBox.ItemHeight = 12;
            this.Item_listBox.Location = new System.Drawing.Point(0, 345);
            this.Item_listBox.Name = "Item_listBox";
            this.Item_listBox.Size = new System.Drawing.Size(630, 252);
            this.Item_listBox.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.Sets_button,
            this.Help_button});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(630, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // ServiceName_textBox
            // 
            this.ServiceName_textBox.Location = new System.Drawing.Point(142, 38);
            this.ServiceName_textBox.Name = "ServiceName_textBox";
            this.ServiceName_textBox.Size = new System.Drawing.Size(388, 19);
            this.ServiceName_textBox.TabIndex = 2;
            // 
            // URL_textBox
            // 
            this.URL_textBox.Location = new System.Drawing.Point(142, 83);
            this.URL_textBox.Name = "URL_textBox";
            this.URL_textBox.Size = new System.Drawing.Size(388, 19);
            this.URL_textBox.TabIndex = 3;
            // 
            // ID_textBox
            // 
            this.ID_textBox.Location = new System.Drawing.Point(142, 128);
            this.ID_textBox.Name = "ID_textBox";
            this.ID_textBox.Size = new System.Drawing.Size(388, 19);
            this.ID_textBox.TabIndex = 4;
            // 
            // Mail_textBox
            // 
            this.Mail_textBox.Location = new System.Drawing.Point(142, 175);
            this.Mail_textBox.Name = "Mail_textBox";
            this.Mail_textBox.Size = new System.Drawing.Size(388, 19);
            this.Mail_textBox.TabIndex = 5;
            // 
            // Psw_textBox
            // 
            this.Psw_textBox.Location = new System.Drawing.Point(142, 218);
            this.Psw_textBox.Name = "Psw_textBox";
            this.Psw_textBox.Size = new System.Drawing.Size(388, 19);
            this.Psw_textBox.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "サービス名";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(85, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "URL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "メール";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "パスワード";
            // 
            // Memo_richTextBox
            // 
            this.Memo_richTextBox.Location = new System.Drawing.Point(142, 254);
            this.Memo_richTextBox.Name = "Memo_richTextBox";
            this.Memo_richTextBox.Size = new System.Drawing.Size(388, 83);
            this.Memo_richTextBox.TabIndex = 13;
            this.Memo_richTextBox.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(90, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "メモ";
            // 
            // No_button
            // 
            this.No_button.Location = new System.Drawing.Point(546, 314);
            this.No_button.Name = "No_button";
            this.No_button.Size = new System.Drawing.Size(74, 23);
            this.No_button.TabIndex = 15;
            this.No_button.Text = "button1";
            this.No_button.UseVisualStyleBackColor = true;
            this.No_button.Click += new System.EventHandler(this.No_button_Click);
            // 
            // OK_button
            // 
            this.OK_button.Location = new System.Drawing.Point(546, 254);
            this.OK_button.Name = "OK_button";
            this.OK_button.Size = new System.Drawing.Size(74, 45);
            this.OK_button.TabIndex = 16;
            this.OK_button.Text = "button2";
            this.OK_button.UseVisualStyleBackColor = true;
            this.OK_button.Click += new System.EventHandler(this.OK_button_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.New_button,
            this.Edit_button,
            this.Delete_button});
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(44, 22);
            this.toolStripButton1.Text = "項目";
            // 
            // New_button
            // 
            this.New_button.Name = "New_button";
            this.New_button.Size = new System.Drawing.Size(98, 22);
            this.New_button.Text = "新規";
            this.New_button.Click += new System.EventHandler(this.New_button_Click);
            // 
            // Edit_button
            // 
            this.Edit_button.Name = "Edit_button";
            this.Edit_button.Size = new System.Drawing.Size(98, 22);
            this.Edit_button.Text = "編集";
            this.Edit_button.Click += new System.EventHandler(this.Edit_button_Click);
            // 
            // Delete_button
            // 
            this.Delete_button.Name = "Delete_button";
            this.Delete_button.Size = new System.Drawing.Size(98, 22);
            this.Delete_button.Text = "削除";
            this.Delete_button.Click += new System.EventHandler(this.Delete_button_Click);
            // 
            // Sets_button
            // 
            this.Sets_button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Sets_button.Image = ((System.Drawing.Image)(resources.GetObject("Sets_button.Image")));
            this.Sets_button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Sets_button.Name = "Sets_button";
            this.Sets_button.Size = new System.Drawing.Size(35, 22);
            this.Sets_button.Text = "設定";
            // 
            // Help_button
            // 
            this.Help_button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Help_button.Image = ((System.Drawing.Image)(resources.GetObject("Help_button.Image")));
            this.Help_button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Help_button.Name = "Help_button";
            this.Help_button.Size = new System.Drawing.Size(40, 22);
            this.Help_button.Text = "ヘルプ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SCLIP.Properties.Resources._001;
            this.pictureBox1.Location = new System.Drawing.Point(0, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(630, 309);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(630, 597);
            this.Controls.Add(this.OK_button);
            this.Controls.Add(this.No_button);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Memo_richTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Psw_textBox);
            this.Controls.Add(this.Mail_textBox);
            this.Controls.Add(this.ID_textBox);
            this.Controls.Add(this.URL_textBox);
            this.Controls.Add(this.ServiceName_textBox);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.Item_listBox);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "SCLIP";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Item_listBox;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem New_button;
        private System.Windows.Forms.ToolStripMenuItem Edit_button;
        private System.Windows.Forms.ToolStripMenuItem Delete_button;
        private System.Windows.Forms.TextBox ServiceName_textBox;
        private System.Windows.Forms.TextBox URL_textBox;
        private System.Windows.Forms.TextBox ID_textBox;
        private System.Windows.Forms.TextBox Mail_textBox;
        private System.Windows.Forms.TextBox Psw_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox Memo_richTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button No_button;
        private System.Windows.Forms.Button OK_button;
        private System.Windows.Forms.ToolStripButton Sets_button;
        private System.Windows.Forms.ToolStripButton Help_button;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

