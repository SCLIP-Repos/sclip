﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCLIP
{
    internal class Paths
    {

        internal static string[] Dirs =
        {
            appdata + @"conf\",

            appdata + @"save\"
        };

        internal static string[] Files =
        {
            appdata + @"conf\au",
            appdata + @"conf\il",
            appdata + @"conf\backupcode"
        };


        private static string appdata = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\sclip\";
    }
}
