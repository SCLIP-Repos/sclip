﻿namespace SCLIP
{
    public partial class Form1
    {
        public enum PanelChannel
        {
            Init,
            View,
            Edit,
            
        }

     
    }
}
