﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SCLIP
{
    public partial class Form1 : Form
    {
        private char mode =' ';

        internal static bool pass = false;

        public Form1()
        {
            InitializeComponent();

            PanelMode(PanelChannel.Init);
        }

       
        private void Form1_Load(object sender, EventArgs e)
        {
            if(!Directory.Exists(Paths.Dirs[0]))
            {
                Setup setup = new Setup();

                setup.ShowDialog();


                if (pass == false)
                    this.Close();
            }
            
        }
        private void New_button_Click(object sender, EventArgs e)
        {
            mode = 'n';

            PanelMode(PanelChannel.Edit);
            
        }

        private void Edit_button_Click(object sender, EventArgs e)
        {
            mode = 'e';

            PanelMode(PanelChannel.Edit);

        }

        private void Delete_button_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("選択されている項目を削除しますか？","削除",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2);


        }


        
        private void OK_button_Click(object sender, EventArgs e)
        {
            string tmp;

            Act.Item item = new Act.Item();


            if (mode == ' ')
                return;


            if(mode == 'n')
            {

                if(item.isItems(ServiceName_textBox.Text))
                {
                    MessageBox.Show("すでに同じ項目が存在します。");
                    return;
                }



                //ファイルの作成
                item.Create(ServiceName_textBox.Text);

                //モードをEditに変更
                mode = 'e';

                //モードがEditの状態で再帰(これにより書き込み)
                OK_button_Click(sender, e);
            }
            else if(mode == 'e')
            {
                //各テキストの結合
                tmp = ServiceName_textBox.Text + "," + URL_textBox.Text + "," + ID_textBox.Text + "," + Mail_textBox.Text + "," + Psw_textBox.Text + "," + Memo_richTextBox.Text;

                //書き込み
                item.Write(ServiceName_textBox.Text, tmp);
            }

            mode = ' ';
           
        }

        private void No_button_Click(object sender, EventArgs e)
        {
            PanelMode(PanelChannel.Init);
        }





        private void PanelMode(Enum @enum)
        {
            switch (@enum)
            {
                case PanelChannel.Init:
                    ServiceName_textBox.Visible = false;
                    URL_textBox.Visible = false;
                    ID_textBox.Visible = false;
                    Mail_textBox.Visible = false;
                    Psw_textBox.Visible = false;
                    Memo_richTextBox.Visible = false;
                    OK_button.Visible = false;
                    No_button.Visible = false;


                    label1.Visible = false;
                    label2.Visible = false;
                    label3.Visible = false;
                    label4.Visible = false;
                    label5.Visible = false;
                    label6.Visible = false;

                    pictureBox1.Visible = true;
                    break;

                case PanelChannel.View:

                    PanelMode(PanelChannel.Init);

                    ServiceName_textBox.Visible = true;
                    URL_textBox.Visible = true;
                    ID_textBox.Visible = true;
                    Mail_textBox.Visible = true;
                    Psw_textBox.Visible = true;
                    Memo_richTextBox.Visible = true;

                    No_button.Visible = true;




                    label1.Visible = true;
                    label2.Visible = true;
                    label3.Visible = true;
                    label4.Visible = true;
                    label5.Visible = true;
                    label6.Visible = true;

                    pictureBox1.Visible = false;

                    //text
                    No_button.Text = "閉じる";

                    //style
                    ServiceName_textBox.BorderStyle = BorderStyle.None;
                    URL_textBox.BorderStyle = BorderStyle.None;
                    ID_textBox.BorderStyle = BorderStyle.None;
                    Mail_textBox.BorderStyle = BorderStyle.None;
                    Psw_textBox.BorderStyle = BorderStyle.None;
                    Memo_richTextBox.BorderStyle = BorderStyle.None;

                    break;

                case PanelChannel.Edit:
                    PanelMode(PanelChannel.Init);

                    ServiceName_textBox.Visible = true;
                    URL_textBox.Visible = true;
                    ID_textBox.Visible = true;
                    Mail_textBox.Visible = true;
                    Psw_textBox.Visible = true;
                    Memo_richTextBox.Visible = true;

                    OK_button.Visible = true;
                    No_button.Visible = true;

                    label1.Visible = true;
                    label2.Visible = true;
                    label3.Visible = true;
                    label4.Visible = true;
                    label5.Visible = true;
                    label6.Visible = true;

                    pictureBox1.Visible = false;

                    //text
                    OK_button.Text = "セーブ";
                    No_button.Text = "キャンセル";

                    //style
                    ServiceName_textBox.BorderStyle = BorderStyle.FixedSingle;
                    URL_textBox.BorderStyle = BorderStyle.FixedSingle;
                    ID_textBox.BorderStyle = BorderStyle.FixedSingle;
                    Mail_textBox.BorderStyle = BorderStyle.FixedSingle;
                    Psw_textBox.BorderStyle = BorderStyle.FixedSingle;
                    Memo_richTextBox.BorderStyle = BorderStyle.FixedSingle;
                    break;
            }

        }

    }
}
