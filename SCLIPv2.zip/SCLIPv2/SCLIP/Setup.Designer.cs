﻿namespace SCLIP
{
    partial class Setup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NewPsw_textBox = new System.Windows.Forms.TextBox();
            this.ReNewPsw_textBox = new System.Windows.Forms.TextBox();
            this.Backupcode_textBox = new System.Windows.Forms.TextBox();
            this.Finish_button = new System.Windows.Forms.Button();
            this.CreateBc_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // NewPsw_textBox
            // 
            this.NewPsw_textBox.Location = new System.Drawing.Point(93, 30);
            this.NewPsw_textBox.Name = "NewPsw_textBox";
            this.NewPsw_textBox.PasswordChar = '●';
            this.NewPsw_textBox.Size = new System.Drawing.Size(347, 19);
            this.NewPsw_textBox.TabIndex = 0;
            // 
            // ReNewPsw_textBox
            // 
            this.ReNewPsw_textBox.Location = new System.Drawing.Point(93, 76);
            this.ReNewPsw_textBox.Name = "ReNewPsw_textBox";
            this.ReNewPsw_textBox.PasswordChar = '●';
            this.ReNewPsw_textBox.Size = new System.Drawing.Size(347, 19);
            this.ReNewPsw_textBox.TabIndex = 1;
            // 
            // Backupcode_textBox
            // 
            this.Backupcode_textBox.BackColor = System.Drawing.Color.White;
            this.Backupcode_textBox.Location = new System.Drawing.Point(93, 134);
            this.Backupcode_textBox.Name = "Backupcode_textBox";
            this.Backupcode_textBox.ReadOnly = true;
            this.Backupcode_textBox.Size = new System.Drawing.Size(347, 19);
            this.Backupcode_textBox.TabIndex = 2;
            // 
            // Finish_button
            // 
            this.Finish_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Finish_button.Location = new System.Drawing.Point(389, 347);
            this.Finish_button.Name = "Finish_button";
            this.Finish_button.Size = new System.Drawing.Size(75, 23);
            this.Finish_button.TabIndex = 3;
            this.Finish_button.Text = "完了";
            this.Finish_button.UseVisualStyleBackColor = true;
            this.Finish_button.Click += new System.EventHandler(this.Finish_button_Click);
            // 
            // CreateBc_button
            // 
            this.CreateBc_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateBc_button.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.CreateBc_button.Location = new System.Drawing.Point(377, 159);
            this.CreateBc_button.Name = "CreateBc_button";
            this.CreateBc_button.Size = new System.Drawing.Size(63, 41);
            this.CreateBc_button.TabIndex = 4;
            this.CreateBc_button.Text = "🔃";
            this.CreateBc_button.UseVisualStyleBackColor = true;
            this.CreateBc_button.Click += new System.EventHandler(this.CreateBc_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SCLIP.Properties.Resources._001;
            this.pictureBox1.Location = new System.Drawing.Point(7, 171);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(364, 199);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "パスワード";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "確認入力";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "バックアップコード";
            // 
            // Setup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(466, 372);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.CreateBc_button);
            this.Controls.Add(this.Finish_button);
            this.Controls.Add(this.Backupcode_textBox);
            this.Controls.Add(this.ReNewPsw_textBox);
            this.Controls.Add(this.NewPsw_textBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Setup";
            this.Text = "SCLIP";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NewPsw_textBox;
        private System.Windows.Forms.TextBox ReNewPsw_textBox;
        private System.Windows.Forms.TextBox Backupcode_textBox;
        private System.Windows.Forms.Button Finish_button;
        private System.Windows.Forms.Button CreateBc_button;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}